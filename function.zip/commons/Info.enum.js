
const info = {
    ERROR: 'Error',
    ADVERTENCIA: 'Advertencia',
    CONFIRMATION: 'Confirmación'
}

module.exports = info;